import sponsor_1 from "./sponsor-1.jpg";
import sponsor_2 from "./sponsor-2.jpg";
import sponsor_3 from "./sponsor-3.jpg";
import sponsor_4 from "./sponsor-4.jpg";
import sponsor_5 from "./sponsor-5.jpg";

export { sponsor_1, sponsor_2, sponsor_3, sponsor_4, sponsor_5 };
