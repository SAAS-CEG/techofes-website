import T77_logojpg from './T77_logo.jpg';
import T77_logopng from './T77_logo.png';
import img1 from './img1.jpg';
import img2 from './img2.jpg';
import concertNight from './concertNight1.jpg';
import djNight from './djNight.jpg';
import concertNightSmall from './concertNight-small.jpg';
import img3 from './img3.jpeg';
import img4 from './img4.jpeg';
import img5 from './img5.jpeg';
import img6 from './img6.jpg';
import img7 from './img7.jpeg';

export { T77_logojpg, T77_logopng, img1, img2, concertNight, djNight, concertNightSmall, img3, img4, img5, img6, img7 };
